package fundamentals.abstraction.streams;

import java.io.IOException;
import java.util.List;

public class Streams {
    static void main() throws IOException {
        List<Product> products;
        ReadCSV csv=new ReadCSV();
        products=csv.getProducts();
        List<Product> filteredProducts=null;
        for (Product product : products ){
            if(product.getMaxRetailPrice()>=50000){
                filteredProducts.add(product);
            }
        }
        System.out.println(filteredProducts);

    }
}
