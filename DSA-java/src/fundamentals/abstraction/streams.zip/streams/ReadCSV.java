package fundamentals.abstraction.streams;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ReadCSV {
    public List<Product> getProducts() throws IOException {
        File file = new File("C:/pranay d drive/dsa/DSA-java/src/fundamentals/abstraction/streams/products.csv");
        BufferedReader bf=new BufferedReader(new FileReader(file));
        bf.readLine();
        String productdata=bf.readLine();
        List<Product> products=new ArrayList<>();
        while (productdata!=null){
            String[] data=productdata.split(",");
            Product product=new Product();
            product.setId(Integer.parseInt(data[0]));
            product.setName(data[1]);
            product.setDiscount(Integer.parseInt(data[2]));
            product.setAvailable(Boolean.parseBoolean(data[3]));
            product.setCompany(data[4]);
            product.setCategory(data[5]);
            product.setManufacturedYear(Integer.parseInt(data[6]));
            products.add(product);
            productdata=bf.readLine();
        }
        return products;
    }

}
